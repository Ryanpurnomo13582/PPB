package com.example.tugas_2_ppb_menu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ArrayList<Menu> menuArrayList = new ArrayList<>();
    int[] menuPictures = {R.drawable.i_fumie, R.drawable.udanggorengtepung_mayonaise, R.drawable.sup_asparagus};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView mRecyclerView = findViewById(R.id.daftar_menu);
        setUpMenu();
        MenuAdapter mAdapter = new MenuAdapter(this, menuArrayList);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setUpMenu(){

        String[] menuNames = getResources().getStringArray(R.array.menu_names_txt);
        String[] menuDescription = getResources().getStringArray(R.array.menu_descriptions_txt);
        String[] menuPrices = getResources().getStringArray(R.array.menu_price_txt);

        for(int i = 0; i < menuNames.length; i++){
            menuArrayList.add(new Menu(" " + i, menuPictures[i], menuNames[i], menuDescription[i], menuPrices[i]));
        }
    }

    public void toCreate(View v){
        Intent intent1 = new Intent(MainActivity.this, CreateActivity.class);
        startActivity(intent1);
    }
}