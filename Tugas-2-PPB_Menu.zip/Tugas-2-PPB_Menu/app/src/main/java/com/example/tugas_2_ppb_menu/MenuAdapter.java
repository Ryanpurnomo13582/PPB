package com.example.tugas_2_ppb_menu;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MyViewHolder> {

    Context context;
    ArrayList<Menu> menuList;

    public MenuAdapter(Context context, ArrayList<Menu> menuList){
        this.context = context;
        this.menuList = menuList;
    }

    @NonNull
    @Override
    public MenuAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_menu, parent, false);
        return new MenuAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuAdapter.MyViewHolder holder, int position) {
        holder.id_menu.setText(menuList.get(position).getId_menu());
        holder.gambar_menu.setImageResource(menuList.get(position).getGambar_menu());
        holder.nama_menu.setText(menuList.get(position).getNama_menu());
        holder.deskripsi_menu.setText(menuList.get(position).getDeskripsi_menu());
        holder.harga_menu.setText(String.valueOf(menuList.get(position).getHarga_menu()));
        holder.pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(context, MenuDetail.class);
                Menu Menulist = menuList.get(position);

                String[] menuList2 = {Menulist.getId_menu(), String.valueOf(Menulist.getGambar_menu()), Menulist.getNama_menu(), Menulist.getDeskripsi_menu(), Menulist.getHarga_menu()};
                intent1.putExtra("MenuList", menuList2);
                context.startActivity(intent1);
            }
        });
    }

    @Override
    public int getItemCount() {
        return menuList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView gambar_menu;
        TextView id_menu, nama_menu, deskripsi_menu, harga_menu;
        Button pesan;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            id_menu = itemView.findViewById(R.id.tv_id_menu);
            gambar_menu = itemView.findViewById(R.id.iv_gambar_menu);
            nama_menu = itemView.findViewById(R.id.tv_nama_menu);
            deskripsi_menu = itemView.findViewById(R.id.tv_deskripsi_menu);
            harga_menu = itemView.findViewById(R.id.tv_harga_menu);
            pesan = itemView.findViewById(R.id.btn_lihat_menu);
        }
    }
}
