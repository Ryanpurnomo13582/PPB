package com.example.tugas_2_ppb_menu;

public class Menu {
        String id_menu;
        int gambar_menu;
        String nama_menu;
        String deskripsi_menu;
        String harga_menu;

        public Menu(String id_menu, int gambar_menu, String nama_menu, String deskripsi_menu, String harga_menu){
            this.id_menu = id_menu;
            this.gambar_menu = gambar_menu;
            this.nama_menu = nama_menu;
            this.deskripsi_menu = deskripsi_menu;
            this.harga_menu = harga_menu;
        }

    public String getId_menu() {
        return id_menu;
    }

    public void setId_menu(String id_menu) {
        this.id_menu = id_menu;
    }

    public int getGambar_menu() {
        return gambar_menu;
    }

    public void setGambar_menu(String int_menu) {
        this.gambar_menu = gambar_menu;
    }

    public String getNama_menu() {
        return nama_menu;
    }

    public void setNama_menu(String nama_menu) {
        this.nama_menu = nama_menu;
    }

    public String getHarga_menu() {
        return harga_menu;
    }

    public void setHarga_menu(String harga_menu) {
        this.harga_menu = harga_menu;
    }

    public String getDeskripsi_menu() {
        return deskripsi_menu;
    }

    public void setDeskripsi_menu(String deskripsi_menu) {
        this.deskripsi_menu = deskripsi_menu;
    }
}
