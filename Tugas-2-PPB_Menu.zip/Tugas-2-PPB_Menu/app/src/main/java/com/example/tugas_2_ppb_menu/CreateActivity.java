package com.example.tugas_2_ppb_menu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

public class CreateActivity extends AppCompatActivity {
    protected Cursor cursor;
    Database database;
    EditText food_name, food_description, food_prices;
    ImageView food_pictures;
    Button btnSubmit, btnEdit;
    public static final int CAMERA_REQUEST = 100;
    public static final int STORAGE_REQUEST = 101;

    String[]cameraPermission;
    String[]storagePermission;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        /*database = new Database(this);
        findId();
        insertData();*/
    }
    /*
    private void insertData(){
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SQLiteDatabase db = database.getWritableDatabase();

                ContentValues cv = new ContentValues();
                cv.put("avatar",ImageViewToByte(food_pictures));

                byte[]simpangambar=ImageViewToByte(food_pictures);
                db.execSQL("INSERT INTO makanan(gambar_makanan, nama_makanan, deskripsi_makanan, harga_makanan) VALUES('" + food_pictures.getImageAlpha() + "', '" + food_name.getText().toString() + "')");
                Toast.makeText(CreateActivity.this, "Data tersimpan", Toast.LENGTH_SHORT).show();
                MainActivity2.mainActivity2.RefreshList();
                finish();
            }
        });
    }

    private byte[] ImageViewToByte(ImageView avatar){
        Bitmap bitmap = ((BitmapDrawable)avatar.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream);
        byte[]bytes = stream.toByteArray();
        return bytes;
    }

    private void findId(){
        food_pictures = findViewById(R.id.edit_food_pictures);
        food_name = findViewById(R.id.edit_food_name);
        food_description = findViewById(R.id.edit_food_description);
        food_prices = findViewById(R.id.edit_food_prices);
        btnSubmit = findViewById(R.id.btn_submit);
    }*/
}