
package com.example.tugas_2_ppb_menu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.NumberFormat;
import java.util.ArrayList;

public class MenuDetail extends AppCompatActivity {
    private static String total_harga_menu_kirim;
    //private ArrayList<String> receivedDataList;

    String idMenu, gambarMenuS, namaMenu, deskripsiMenu, hargaMenu, totalhargaMenu, total_harga_menu2;
    String[] arrOfML;
    FloatingActionButton tmbhItem, krngItem;
    TextView tv_kuantitas_menu, tv_total_harga_menu;
    int gambarMenu;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_detail);
        arrOfML = getIntent().getStringArrayExtra("MenuList");
        tmbhItem = findViewById(R.id.tmbhItem);
        krngItem = findViewById(R.id.krngItem);
        tmbhItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_kuantitas_menu = findViewById(R.id.tv_kuantitas_menu);
                tv_total_harga_menu = findViewById(R.id.tv_total_harga_menu);
                String kuantitas_menuS = tv_kuantitas_menu.getText().toString();
                String total_harga_menuS = tv_total_harga_menu.getText().toString();
                int kuantitas_menu = translateStrtoInt(kuantitas_menuS);
                int total_harga_menu = translateStrtoInt(total_harga_menuS);
                total_harga_menu2 = arrOfML[4];
                int total_harga_menuS2 = translateStrtoInt(total_harga_menu2);
                kuantitas_menu+=1;
                total_harga_menu=total_harga_menuS2*kuantitas_menu;
                kuantitas_menuS = String.valueOf(kuantitas_menu);
                total_harga_menuS = String.valueOf(total_harga_menu);
                setData(total_harga_menuS);
                //tambahPemisahRibuan(total_harga_menu);
                tv_kuantitas_menu.setText(kuantitas_menuS);
                tv_total_harga_menu.setText(total_harga_menuS);
            }
        });
        krngItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv_kuantitas_menu = findViewById(R.id.tv_kuantitas_menu);
                tv_total_harga_menu = findViewById(R.id.tv_total_harga_menu);
                String kuantitas_menuS = tv_kuantitas_menu.getText().toString();
                String total_harga_menuS = tv_total_harga_menu.getText().toString();
                int kuantitas_menu = translateStrtoInt(kuantitas_menuS);
                int total_harga_menu = translateStrtoInt(total_harga_menuS);
                int pengurangan = total_harga_menu/kuantitas_menu;
                kuantitas_menu-=1;
                total_harga_menu = total_harga_menu-pengurangan;
                kuantitas_menuS = String.valueOf(kuantitas_menu);
                //tambahPemisahRibuan(total_harga_menu);
                total_harga_menuS = String.valueOf(total_harga_menu);
                setData(total_harga_menuS);
                tv_kuantitas_menu.setText(kuantitas_menuS);
                tv_total_harga_menu.setText(total_harga_menuS);
            }
        });
        tampilDetailItem(arrOfML);
        /*Intent intent = getIntent();
        String IDMenu = intent.getStringExtra("MenuList");*/
    }

    public void tampilDetailItem(String[] str){
        if (arrOfML != null) {
            idMenu = arrOfML[0];
            gambarMenuS = arrOfML[1];
            namaMenu = arrOfML[2];
            deskripsiMenu = arrOfML[3];
            hargaMenu = arrOfML[4];
            totalhargaMenu = arrOfML[4];
            int gambarMenu = Integer.parseInt(gambarMenuS);


            TextView tv_id_menu = findViewById(R.id.tv_id_menu);
            ImageView iv_gambar_menu = findViewById(R.id.iv_gambar_menu);
            TextView tv_nama_menu = findViewById(R.id.tv_nama_menu);
            TextView tv_deskripsi_menu = findViewById(R.id.tv_deskripsi_menu);
            TextView tv_harga_menu = findViewById(R.id.tv_harga_menu);
            tv_total_harga_menu = findViewById(R.id.tv_total_harga_menu);

            tv_id_menu.setText(" " + idMenu);
            iv_gambar_menu.setImageResource(gambarMenu);
            tv_nama_menu.setText(" " + namaMenu);
            tv_deskripsi_menu.setText(" " + deskripsiMenu);
            tv_harga_menu.setText(" " + hargaMenu);
            tv_total_harga_menu.setText(totalhargaMenu);
        }
    }

    public int translateStrtoInt(String value){
        String value1 = value.replace(".", "");
        int value2 = Integer.parseInt(value1);
        return value2;
    }

    public static String tambahPemisahRibuan(int number) {
        String numberString = String.valueOf(number);
        int length = numberString.length();

        StringBuilder formattedNumber = new StringBuilder();
        for (int i = 0; i < length; i++) {
            formattedNumber.append(numberString.charAt(i));
            if ((length - i - 1) % 3 == 0 && i != length - 1) {
                formattedNumber.append('.');
            }
        }

        return formattedNumber.toString();
    }

    public void Tambah(View v){
        arrOfML = getIntent().getStringArrayExtra("MenuList");
        Intent intent1 = new Intent(MenuDetail.this, OrderDetail.class);
        intent1.putExtra("arrOfML", arrOfML);
        startActivity(intent1);
    }

    public void setData(String total_harga_menu_kirim){
        this.total_harga_menu_kirim = total_harga_menu_kirim;
    }

    public static String getData(){
        return total_harga_menu_kirim;
    }
    /*

    public int hitungTotalHarga(int value, int value1){
        int value2 = value1;
        int value3 = 1;
        int value4;
        if(value2 > value3){
            value*=value2;
            value4 = value2;
        }
        else {
            value4 = value2;
            value/=value4;
        }
        return value;
    }*/
}
