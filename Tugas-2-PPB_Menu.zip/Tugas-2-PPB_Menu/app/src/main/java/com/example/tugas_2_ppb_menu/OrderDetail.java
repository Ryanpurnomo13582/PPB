package com.example.tugas_2_ppb_menu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class OrderDetail extends AppCompatActivity {
    String idMenu, gambarMenuS, namaMenu, deskripsiMenu, hargaMenu, totalhargaMenu,total_harga_menu2;
    TextView tv_id_menu, tv_nama_menu, tv_harga_menu, tv_total_harga_menu;
    ImageView iv_gambar_menu;
    String[] arrOfML2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        arrOfML2 = getIntent().getStringArrayExtra("arrOfML");
        tampilDetailItem(arrOfML2);
    }

    public void Menu(View v){
        Intent intent1 = new Intent(OrderDetail.this, MainActivity.class);
        startActivity(intent1);
    }

    public void tampilDetailItem(String str[]){
        if (arrOfML2 != null) {
            idMenu = arrOfML2[0];
            gambarMenuS = arrOfML2[1];
            namaMenu = arrOfML2[2];
            //deskripsiMenu = arrOfML[3];
            hargaMenu = arrOfML2[4];
            totalhargaMenu = MenuDetail.getData();
            int gambarMenu = Integer.parseInt(gambarMenuS);

            tv_id_menu = findViewById(R.id.tv_id_menu);
            iv_gambar_menu = findViewById(R.id.iv_gambar_menu);
            tv_nama_menu = findViewById(R.id.tv_nama_menu);
            //tv_deskripsi_menu = findViewById(R.id.tv_deskripsi_menu);
            tv_harga_menu = findViewById(R.id.tv_harga_menu);
            tv_total_harga_menu = findViewById(R.id.tv_total_harga_menu);

            tv_id_menu.setText(" " + idMenu);
            iv_gambar_menu.setImageResource(gambarMenu);
            tv_nama_menu.setText(" " + namaMenu);
            //tv_deskripsi_menu.setText(" " + deskripsiMenu);
            tv_harga_menu.setText(" " + hargaMenu);
            tv_total_harga_menu.setText(totalhargaMenu);
        }
    }

    public int translateStrtoInt(String value){
        String value1 = value.replace(".", "");
        int value2 = Integer.parseInt(value1);
        return value2;
    }
}