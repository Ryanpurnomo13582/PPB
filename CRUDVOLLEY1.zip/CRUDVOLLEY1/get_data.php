<?php

	include "koneksi.php";
	
	$query = "SELECT * FROM history";
	$result = mysqli_query($conn, $query);

	$data = array();
	while ($row = mysqli_fetch_assoc($result)) {
    		$data[] = $row;
	}

	echo json_encode($data);

mysqli_close($conn);

?>