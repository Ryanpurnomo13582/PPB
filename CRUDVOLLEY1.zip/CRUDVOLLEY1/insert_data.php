<?php

	include "koneksi.php";

	$id_menu = isset($_POST['id_menu']) ? $_POST['id_menu'] : '';
	$nama_menu = isset($_POST['nama_menu']) ? $_POST['nama_menu'] : '';
	$kuantitas_menu = isset($_POST['kuantitas_menu']) ? $_POST['kuantitas_menu'] : '';
	$harga_menu = isset($_POST['harga_menu']) ? $_POST['harga_menu'] : '';
	$total_harga_menu = isset($_POST['total_harga_menu']) ? $_POST['total_harga_menu'] : ''; 
	
	if(empty($nama_menu) || empty($kuantitas_menu) || empty($total_harga_menu)){
		echo "Kolom isian tidak boleh kosong";
	}else{
		$query = mysqli_query($conn, "INSERT INTO history(id_menu, nama_menu, kuantitas_menu, harga_menu, total_harga_menu) VALUES('".$id_menu."', '".$nama_menu."', '".$kuantitas_menu."', '".$harga_menu."', '".$total_harga_menu."')");
		
		if($query){
			echo "Data berhasil disimpan";
		}else{
			echo "Error simpan data";
		}
		
	}

?>