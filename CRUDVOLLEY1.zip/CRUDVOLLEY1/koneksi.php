<?php
	
$server = "localhost";
$user = "root";
$password = "";
$database = "db_crudvolley_pembayaran";

$conn = mysqli_connect($server, $user, $password, $database);

?>