package com.example.tugas_1_ppb_resto;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Maps extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_maps);
        Intent intent = getIntent();
        Boolean click = intent.getBooleanExtra("openMap",true);
        if(click) {
            this.openMap();
        }
    }

    public void openMap() {
        String location = "Jl. Pringgading No. 76, Jagalan, Semarang Tengah, Semarang";
        Uri uri = Uri.parse("geo:0,0?q="+ location);
        Intent intent = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(intent);
    }
}
