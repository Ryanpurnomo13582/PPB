package com.example.tugas_1_ppb_resto;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuAdapter;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AdapterMenu extends RecyclerView.Adapter<AdapterMenu.MyViewHolder> {
    Context context;
    ArrayList<Menu> menuList;

    public AdapterMenu(Context context, ArrayList<Menu> menuList){
        this.context = context;
        this.menuList = menuList;
    }

    @NonNull
    @Override
    public AdapterMenu.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_menu, parent, false);
        return new AdapterMenu.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMenu.MyViewHolder holder, int position) {
        holder.id_menu.setText(menuList.get(position).getId_menu());
        holder.nama_menu.setText(menuList.get(position).getNama_menu());
        holder.harga_menu.setText(String.valueOf(menuList.get(position).getHarga_menu()));
    }

    @Override
    public int getItemCount() {
        return menuList.size();
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView gambar_menu;
        TextView id_menu, nama_menu, deskripsi_menu, harga_menu;
        Button pesan;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id_menu = itemView.findViewById(R.id.tv_id_menu);
            nama_menu = itemView.findViewById(R.id.tv_nama_menu);
            harga_menu = itemView.findViewById(R.id.tv_harga_menu);
        }
    }
}
