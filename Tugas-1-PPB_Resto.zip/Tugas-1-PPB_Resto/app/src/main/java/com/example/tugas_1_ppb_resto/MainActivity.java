package com.example.tugas_1_ppb_resto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Menu> menuArrayList = new ArrayList<>();
    int[] menuPictures = {R.drawable.i_fumie, R.drawable.udanggorengtepung_mayonaise, R.drawable.sup_asparagus};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView mRecyclerView = findViewById(R.id.daftar_menu);
        setUpMenu();
        AdapterMenu mAdapter = new AdapterMenu(this, menuArrayList);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        TextView hourListView = findViewById(R.id.detail_text);
        TextView hourListView2 = findViewById(R.id.detail_text2);
        ImageView Dropdownbutton = findViewById(R.id.dropdown_button);

        Dropdownbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(hourListView.getVisibility() == View.GONE){
                    hourListView.setVisibility(View.VISIBLE);
                    hourListView2.setVisibility(View.VISIBLE);
                    Dropdownbutton.setImageResource(R.drawable.dropup_icon);
                }else{
                    hourListView.setVisibility(View.GONE);
                    hourListView2.setVisibility(View.GONE);
                    Dropdownbutton.setImageResource(R.drawable.dropdown_icon);
                }
            }
        });
    }

    public void gmail(View v){
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"ryanhero81@gmail.com"});
        intent.putExtra(Intent.EXTRA_SUBJECT, "Subjek Email");
        intent.putExtra(Intent.EXTRA_TEXT, "Isi pesan email");
        intent.setPackage("com.google.android.gm"); // Ini menentukan untuk menggunakan Gmail
        startActivity(intent);
    }

    public void phoneCall(View v){
        String nomor = "0895632363226";
        Uri uri = Uri.parse("tel:"+ nomor);
        Intent intent2 = new Intent(Intent.ACTION_DIAL, uri);
        startActivity(intent2);
    }

    public void maps(View v){
        Intent intent3 = new Intent(this, Maps.class);
        Boolean click = true;
        intent3.putExtra("openMap",click);
        startActivity(intent3);
    }

    private void setUpMenu(){

        String[] menuNames = getResources().getStringArray(R.array.menu_names_txt);
        String[] menuDescription = getResources().getStringArray(R.array.menu_descriptions_txt);
        String[] menuPrices = getResources().getStringArray(R.array.menu_price_txt);

        for(int i = 0; i < menuNames.length; i++){
            menuArrayList.add(new Menu(" " + i, menuPictures[i], menuNames[i], menuDescription[i], menuPrices[i]));
        }
    }
}