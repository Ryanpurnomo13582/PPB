package com.example.tugas_3_ppb_pemesanan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.MyViewHolder>{
    ArrayList<History> historyArrayList;

    public HistoryAdapter(ArrayList<History> historyArrayList){
        this.historyArrayList = historyArrayList;
    }

    @NonNull
    @Override
    public HistoryAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.activity_history_payed, parent, false);
        return new HistoryAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(HistoryAdapter.MyViewHolder holder, int position) {
        holder.id_menu.setText(historyArrayList.get(position).getId_menu());
        holder.nama_menu.setText(historyArrayList.get(position).getNama_menu());
        holder.kuantitas_menu.setText(String.valueOf(historyArrayList.get(position).getKuantitas_menu()));
        holder.total_harga_menu.setText(String.valueOf(historyArrayList.get(position).getHarga_menu()));
        holder.total_harga_menu_dipesan.setText(historyArrayList.get(position).getTotal_harga_menu());
    }

    @Override
    public int getItemCount() {
        return historyArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView gambar_menu;
        TextView id_menu, nama_menu, kuantitas_menu, total_harga_menu, total_harga_menu_dipesan;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id_menu = itemView.findViewById(R.id.tv_id_menu);
            nama_menu = itemView.findViewById(R.id.tv_nama_menu);
            kuantitas_menu = itemView.findViewById(R.id.tv_kuantitas_menu);
            total_harga_menu = itemView.findViewById(R.id.tv_total_harga_menu);
            total_harga_menu_dipesan = itemView.findViewById(R.id.tv_total_harga_menu_dipesan);
        }
    }
}
