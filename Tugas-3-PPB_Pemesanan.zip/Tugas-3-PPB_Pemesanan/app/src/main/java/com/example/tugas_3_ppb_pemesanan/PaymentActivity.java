package com.example.tugas_3_ppb_pemesanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class PaymentActivity extends AppCompatActivity {
    public static final String url = "http://192.168.1.9/Semester Antara 1/PPB/CRUDVOLLEY1/insert_data.php";
    int i = 0;
    String data1, data2, data4, data5;
    int data3;
    PaymentAdapter pAdapter;
    ArrayList<Payment> paymentArrayList = new ArrayList<>();
    TextView id_menu_disimpan, nama_menu_disimpan, kuantitas_menu_disimpan, harga_menu_disimpan, total_harga_akhir_disimpan, keterangan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        String[] data1Arr = new String[10];
        String[] data2Arr = new String[10];
        int[] data3Arr = new int[10];
        String[] data4Arr = new String[10];
        String[] data5Arr = new String[10];
        data1Arr = getIntent().getStringArrayExtra("dataIdArr");
        data2Arr = getIntent().getStringArrayExtra("dataNamaArr");
        data3Arr = getIntent().getIntArrayExtra("dataKuantitasArr");
        data4Arr = getIntent().getStringArrayExtra("dataHargaArr");
        data5Arr = getIntent().getStringArrayExtra("dataTotalHargaArr");
        data1 = data1Arr[i];
        data2 = data2Arr[i];
        data3 = data3Arr[i];
        data4 = data4Arr[i];
        data5 = data5Arr[i];
        TambahMenuDipesan(data1, data2, data3, data4, data5);
        //String data2 = null;
        /*if (data2Arr != null) {
            // Gunakan receivedArray sesuai kebutuhan
            for (String data : data2Arr) {
                data2 = data;
            }
        }*/
        id_menu_disimpan = findViewById(R.id.tv_id_menu_disimpan);
        nama_menu_disimpan = findViewById(R.id.tv_nama_menu_disimpan);
        kuantitas_menu_disimpan = findViewById(R.id.tv_kuantitas_menu_disimpan);
        harga_menu_disimpan = findViewById(R.id.tv_harga_menu_disimpan);
        total_harga_akhir_disimpan = findViewById(R.id.tv_total_harga_tetap_disimpan);
        //keterangan = findViewById(R.id.tv_keterangan);

        id_menu_disimpan.setText(data1);
        nama_menu_disimpan.setText(data2);
        kuantitas_menu_disimpan.setText(String.valueOf(data3));
        harga_menu_disimpan.setText(data4);
        total_harga_akhir_disimpan.setText(data5);
        RecyclerView mRecyclerView = findViewById(R.id.daftar_semua_menu_dipesan);
        pAdapter = new PaymentAdapter(this, paymentArrayList);
        mRecyclerView.setAdapter(pAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button btnSimpan = findViewById(R.id.coba_simpan);
        btnSimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputDatatoMySQL();
            }
        });
    }

    public void PayTransfer(View v){
        inputDatatoMySQL();
        Intent intent1 = new Intent(this, HistoryActivity.class);
        startActivity(intent1);
    }

    public int translateStrtoInt(String value){
        String value1 = value.replace(".", "");
        int value2 = Integer.parseInt(value1);
        return value2;
    }

    public void TambahMenuDipesan(String dataId, String dataNama, int dataKuantitas, String dataHarga, String dataTotalHarga){
        paymentArrayList.add(new Payment(dataId, dataNama, dataKuantitas, dataHarga, dataTotalHarga));
    }


    private void inputDatatoMySQL(){
        String dataId = id_menu_disimpan.getText().toString();
        String dataNama = nama_menu_disimpan.getText().toString();
        String dataKuantitasS = kuantitas_menu_disimpan.getText().toString();
        int dataKuantitas = Integer.parseInt(dataKuantitasS);
        String dataHarga = harga_menu_disimpan.getText().toString();
        String dataTotalHarga = total_harga_akhir_disimpan.getText().toString();

        JSONObject requestData = new JSONObject();
        try {
            requestData.put("id_menu", dataId);
            requestData.put("nama_menu", dataNama);
            requestData.put("kuantitas_menu", dataKuantitas);
            requestData.put("harga_menu", dataHarga);
            requestData.put("total_harga_menu", dataTotalHarga);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle response from server
                        keterangan.setText((CharSequence) response);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        keterangan.setText(error.getMessage());// Handle error
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id_menu", dataId.toString());
                params.put("nama_menu", dataNama.toString());
                params.put("kuantitas_menu", dataKuantitasS.toString());
                params.put("harga_menu", dataHarga.toString());
                params.put("total_harga_menu", dataTotalHarga.toString());

                // Mengirimkan JSON sebagai String
                return params;
            }
        };
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }
}