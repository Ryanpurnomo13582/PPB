package com.example.tugas_3_ppb_pemesanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String dataKuantitas1 = "";
    int dataKuantitas, dataHarga, dtH2 = 0;;
    private String dataId = "";
    private String dataNama = "";
    private String dataHarga1 = "";
    private String datatotalHarga1 = "";
    int jumlahData;
    int[] menuPictures = {R.drawable.i_fumie, R.drawable.udanggorengtepung_mayonaise, R.drawable.sup_asparagus};
    String[] menuNames, menuDescription, menuPrices;
    String dataKuantitas2;

    ArrayList<Menu> menuArrayList = new ArrayList<>();
    ArrayList<Payment> paymentArrayList = new ArrayList<>();
    MenuAdapter mAdapter;
    TextView tv_total_kuantitas_dipesan, tv_total_harga_dipesan, textView1, textView2, textView3, textView4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView mRecyclerView = findViewById(R.id.daftar_keranjang_menu);
        tv_total_kuantitas_dipesan = findViewById(R.id.tv_total_kuantitas_dipesan);
        tv_total_harga_dipesan = findViewById(R.id.tv_total_harga_dipesan);
        TambahDaftarMenu();
        mAdapter = new MenuAdapter(this, menuArrayList);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        /*int total_harga_dipesanS = HitungHargaDaftarMenu();
        TextView textView3 = findViewById(R.id.tv_total_harga_dipesan3);
        textView3.setText(String.valueOf(total_harga_dipesanS));*/
    }

    public void setDataDariMenuAdapter(String id, String nama, String kuantitas, String harga, String totalharga){
        int datatotalHarga = 0;
        int dataHarga2 = 0;
        dataId = id;
        dataNama = nama;
        dataKuantitas1 = kuantitas;
        dataHarga1 = harga;
        datatotalHarga1 = totalharga;


        // Atau menampilkan data pada elemen UI, seperti TextView
        textView1 = findViewById(R.id.tv_id_menu_dipesan);
        textView2 = findViewById(R.id.tv_nama_menu_dipesan);
        textView3 = findViewById(R.id.tv_total_kuantitas_dipesan);
        textView4 = findViewById(R.id.tv_total_harga_menu_dipesan);


        textView1.setText(dataId);
        textView2.setText(dataNama);
        dataKuantitas = Integer.parseInt(dataKuantitas1);
        textView3.setText(dataKuantitas1);
        textView4.setText(datatotalHarga1);


        dataHarga2 = Integer.parseInt(datatotalHarga1);
        int total_kuantitas_dipesanS = HitungVariasiDaftarHarga();
        String total_kuantitas_dipesan = String.valueOf(total_kuantitas_dipesanS);
        tv_total_harga_dipesan.setText(total_kuantitas_dipesan);
    }

    private void TambahDaftarMenu(){
        menuNames = getResources().getStringArray(R.array.menu_names_txt);
        menuDescription = getResources().getStringArray(R.array.menu_descriptions_txt);
        menuPrices = getResources().getStringArray(R.array.menu_price_txt);

        for(int i = 0; i < menuNames.length; i++){
            menuArrayList.add(new Menu("" + i, menuPictures[i], menuNames[i], menuDescription[i], menuPrices[i]));
        }
    }

    public Integer HitungVariasiDaftarMenu(){
        jumlahData = menuArrayList.size();
        int j = 0;
        int k = 1;
        int total1 = 0, total2 = 0;
        String [] ArrayID = new String[0];
        Integer [] ArrayItem = new Integer[jumlahData];
            int i = 0;
            while (i >= 0 && i < jumlahData) {
                //Menghitung kuantitas variasi item * kuantitas item yang dipesan
                if (j < k){
                    j = k;
                ArrayItem[i] = j;
                total1 = total1 + ArrayItem[i];
                j = 0;
                }
                //Menghitung harga dari variasi item * kuantitas item yang dipesan
                i++;
            }
            return total1;
    }

    public Integer HitungVariasiDaftarHarga(){
        int dtH;
        int [] SimpanA = new int[100];
        int i = 0, j = 0;
        TextView textViewcoba1 = findViewById(R.id.tv_id_menu_dipesan);
        TextView textViewcoba2 = findViewById(R.id.tv_total_harga_menu_dipesan);
        String dataHargaCobaS = textViewcoba2.getText().toString();
        int dataHargaCoba = Integer.parseInt(dataHargaCobaS);
        String dataIdCobaS = textViewcoba1.getText().toString();
        int dataIdCoba = Integer.parseInt(dataIdCobaS);
        SimpanA[i] = dataIdCoba;
        i++;
            if(SimpanA[i-1] != dataIdCoba){
                dtH2 += dataHargaCoba;
                dtH = dtH2;
                SimpanA[i-1] = SimpanA[i];
            }else{
                dtH2 = dataHargaCoba;
                dtH = dtH2;
            }
        return dtH;
    }

    public void Pay(View v){
        textView1 = findViewById(R.id.tv_id_menu_dipesan);
        textView2 = findViewById(R.id.tv_total_kuantitas_dipesan);
        textView3 = findViewById(R.id.tv_total_harga_dipesan);
        textView4 = findViewById(R.id.tv_nama_menu_dipesan);
        TextView textView5 = findViewById(R.id.tv_total_harga_menu_dipesan);
        TextView textView6 = findViewById(R.id.tv_harga_menu_tetap);
        int i = 0;
        String [] dataIdArr = new String[50];
        String [] dataNamaArr = new String[100];
        int[] dataKuantitasArr = new int[50];
        String[] dataHargaArr = new String[50];
        String [] datatotalHargaArr = new String[50];
        String dataId = textView1.getText().toString();
        String dataNama = textView4.getText().toString();
        int dataKuantitas = Integer.parseInt(textView2.getText().toString());
        String dataHarga = textView6.getText().toString();
        String datatotalHarga1 = textView3.getText().toString();
        dataIdArr[i] = dataId;
        dataNamaArr[i] = dataNama;
        dataKuantitasArr[i] = dataKuantitas;
        dataHargaArr[i] = dataHarga;
        datatotalHargaArr[i] = datatotalHarga1;
        Intent intent1 = new Intent(this, PaymentActivity.class);
        /*if(dataNama2[i] == null) {
            dataNama2[i] = dataNama;
            i++;
        }*/
        intent1.putExtra("dataIdArr", dataIdArr);
        intent1.putExtra("dataNamaArr", dataNamaArr);
        intent1.putExtra("dataKuantitasArr", dataKuantitasArr);
        intent1.putExtra("dataHargaArr", dataHargaArr);
        intent1.putExtra("dataTotalHargaArr", datatotalHargaArr);
        startActivity(intent1);
    }

    public void History(View v){
        Intent intent2 = new Intent(this, HistoryActivity.class);
        startActivity(intent2);
    }

    public int translateStrtoInt(String value){
        String value1 = value.replace(".", "");
        int value2 = Integer.parseInt(value1);
        return value2;
    }
}