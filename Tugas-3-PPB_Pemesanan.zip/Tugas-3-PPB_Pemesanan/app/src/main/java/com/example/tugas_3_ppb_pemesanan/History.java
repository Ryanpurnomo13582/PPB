package com.example.tugas_3_ppb_pemesanan;

public class History {
    String id_menu;
    String nama_menu;
    int kuantitas_menu;
    String harga_menu;
    String total_harga_menu;

    public History(){

    }

    public History(String id_menu, String nama_menu, int kuantitas_menu, String harga_menu, String total_harga_menu){
        this.id_menu = id_menu;
        this.nama_menu = nama_menu;
        this.kuantitas_menu = kuantitas_menu;
        this.harga_menu = harga_menu;
        this.total_harga_menu = total_harga_menu;
    }

    public String getId_menu() {
        return id_menu;
    }

    public void setId_menu(String id_menu) {
        this.id_menu = id_menu;
    }

    public String getNama_menu() {
        return nama_menu;
    }

    public void setNama_menu(String nama_menu) {
        this.nama_menu = nama_menu;
    }

    public int getKuantitas_menu() {
        return kuantitas_menu;
    }

    public void setKuantitas_menu(int kuantitas_menu) {
        this.kuantitas_menu = kuantitas_menu;
    }

    public String getHarga_menu() {
        return harga_menu;
    }

    public void setHarga_menu(String harga_menu) {
        this.harga_menu = harga_menu;
    }

    public String getTotal_harga_menu() {
        return total_harga_menu;
    }

    public void setTotal_harga_menu(String total_harga_menu) {
        this.total_harga_menu = total_harga_menu;
    }
}
