package com.example.tugas_3_ppb_pemesanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
    ArrayList<History> historyArrayList = new ArrayList<>();
    RecyclerView mrecyclerView;
    HistoryAdapter hAdapter;
    TextView keterangan;
    public static final String url = "http://192.168.1.9/Semester Antara 1/PPB/CRUDVOLLEY1/get_data.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        RequestQueue queue = Volley.newRequestQueue(this);
        mrecyclerView = findViewById(R.id.daftar_semua_riwayat_pesanan);
        mrecyclerView.setLayoutManager(new LinearLayoutManager(this));
        JsonArrayRequest request = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            for (int i = 0; i < response.length(); i++) {

                                JSONObject obj = response.getJSONObject(i);

                                History history = new History();
                                history.setId_menu(obj.getString("id_menu"));
                                history.setNama_menu(obj.getString("nama_menu"));
                                history.setKuantitas_menu(obj.getInt("kuantitas_menu"));
                                history.setHarga_menu(obj.getString("harga_menu"));
                                history.setTotal_harga_menu(obj.getString("total_harga_menu"));
                                historyArrayList.add(history);
                            }
                            hAdapter = new HistoryAdapter(historyArrayList);
                            mrecyclerView.setAdapter(hAdapter);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        keterangan = findViewById(R.id.tv_keterangan);
                        keterangan.setText(error.getMessage());
                    }
                });

        queue.add(request);
        panggil(this);
    }

    public void ToMenu(View v){
        Intent intent1 = new Intent(this, MainActivity.class);
        startActivity(intent1);
    }

    public void panggil(Context context){

    }
}