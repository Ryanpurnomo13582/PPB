package com.example.tugas_3_ppb_pemesanan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.MyViewHolder> {
    //ArrayList<Menu> menuList;
    ArrayList<Payment> paymentArrayList;
    Context context;

    public PaymentAdapter(Context context, ArrayList<Payment> paymentArrayList){
        this.context = context;
        this.paymentArrayList = paymentArrayList;
    }

    @NonNull
    @Override
    public PaymentAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_menu_ordered, parent, false);
        return new PaymentAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentAdapter.MyViewHolder holder, int position) {
        holder.id_menu.setText(paymentArrayList.get(position).getId_menu());
        holder.nama_menu.setText(paymentArrayList.get(position).getNama_menu());
        holder.kuantitas_menu.setText(String.valueOf(paymentArrayList.get(position).getKuantitas_menu()));
        holder.total_harga_menu.setText(String.valueOf(paymentArrayList.get(position).getHarga_menu()));
        holder.total_harga_menu_dipesan.setText(paymentArrayList.get(position).getTotal_harga_menu());
    }

    @Override
    public int getItemCount() {
        return paymentArrayList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView id_menu, nama_menu, total_harga_menu, total_harga_menu_dipesan, kuantitas_menu;
        public MyViewHolder(@NonNull View itemView){
            super(itemView);
            id_menu = itemView.findViewById(R.id.tv_id_menu);
            nama_menu = itemView.findViewById(R.id.tv_nama_menu);
            kuantitas_menu = itemView.findViewById(R.id.tv_kuantitas_menu);
            total_harga_menu = itemView.findViewById(R.id.tv_total_harga_menu);
            total_harga_menu_dipesan = itemView.findViewById(R.id.tv_total_harga_menu_dipesan);
        }
    }

    public int translateStrtoInt(String value){
        String value1 = value.replace(".", "");
        int value2 = Integer.parseInt(value1);
        return value2;
    }
}
