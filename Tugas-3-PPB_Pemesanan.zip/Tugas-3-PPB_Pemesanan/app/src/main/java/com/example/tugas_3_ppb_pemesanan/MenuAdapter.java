package com.example.tugas_3_ppb_pemesanan;


import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MyViewHolder> {
    private String dataDariMenuAdapter = "";
    String kuantitas_menuS, total_harga_menuS, k;
    //TextView kuantitas_menu;
    Context context;
    ArrayList<Menu> menuList;

    public MenuAdapter(Context context, ArrayList<Menu> menuList){
        this.context = context;
        this.menuList = menuList;
    }

    @NonNull
    @Override
    public MenuAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_menu, parent, false);
        return new MenuAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuAdapter.MyViewHolder holder, int position) {
        /*k = getIdMenu(position);
        getIt(k);*/
        holder.id_menu.setText(menuList.get(position).getId_menu());
        holder.gambar_menu.setImageResource(menuList.get(position).getGambar_menu());
        holder.nama_menu.setText(menuList.get(position).getNama_menu());
        //holder.deskripsi_menu.setText(menuList.get(position).getDeskripsi_menu());
        holder.harga_menu.setText(menuList.get(position).getHarga_menu());
        holder.total_harga_menu_kosong.setText(String.valueOf(menuList.get(position).getHarga_menu()));
        holder.tambah_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kuantitas_menuS = holder.returnIt();
                int kuantitas_menu = Integer.parseInt(kuantitas_menuS);
                int total_harga_menu;
                int total_harga_menu2 = translateStrtoInt(menuList.get(position).getHarga_menu());
                kuantitas_menu+=1;
                total_harga_menu=total_harga_menu2*kuantitas_menu;
                kuantitas_menuS = String.valueOf(kuantitas_menu);
                total_harga_menuS = String.valueOf(total_harga_menu);
                String id = menuList.get(position).getId_menu();
                String nama = menuList.get(position).getNama_menu();
                String kuantitas = kuantitas_menuS;
                String harga = menuList.get(position).getHarga_menu();
                String totalharga = total_harga_menuS;
                ((MainActivity) context).setDataDariMenuAdapter(id, nama, kuantitas, harga, totalharga);
                holder.kuantitas_menu.setText(kuantitas_menuS);
                holder.total_harga_menu_kosong.setText(total_harga_menuS);
            }
        });
        holder.kurang_item.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kuantitas_menuS = holder.returnIt();
                int kuantitas_menu = Integer.parseInt(kuantitas_menuS);
                int total_harga_menu = translateStrtoInt(total_harga_menuS);
                int pengurangan = total_harga_menu/kuantitas_menu;
                kuantitas_menu-=1;
                total_harga_menu = total_harga_menu-pengurangan;
                kuantitas_menuS = String.valueOf(kuantitas_menu);
                total_harga_menuS = String.valueOf(total_harga_menu);
                String id = menuList.get(position).getId_menu();
                String nama = menuList.get(position).getNama_menu();
                String kuantitas = kuantitas_menuS;
                String harga = menuList.get(position).getHarga_menu();
                String totalharga = total_harga_menuS;
                ((MainActivity) context).setDataDariMenuAdapter(id, nama, kuantitas, harga, totalharga);
                holder.kuantitas_menu.setText(kuantitas_menuS);
                holder.total_harga_menu_kosong.setText(total_harga_menuS);
            }
        });
    }

    @Override
    public int getItemCount() {
        return menuList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        ImageView gambar_menu;
        TextView id_menu, nama_menu, deskripsi_menu, total_harga_menu_kosong, harga_menu, kuantitas_menu;
        FloatingActionButton tambah_item, kurang_item;
        Button pesan;
        String kM, getKM, iM, getIM;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id_menu = itemView.findViewById(R.id.tv_id_menu);
            gambar_menu = itemView.findViewById(R.id.iv_gambar_menu);
            nama_menu = itemView.findViewById(R.id.tv_nama_menu);
            deskripsi_menu = itemView.findViewById(R.id.tv_deskripsi_menu);
            harga_menu = itemView.findViewById(R.id.tv_harga_menu);
            total_harga_menu_kosong = itemView.findViewById(R.id.tv_total_harga_menu_kosong);
            tambah_item = itemView.findViewById(R.id.tmbhItem);
            kurang_item = itemView.findViewById(R.id.krngItem);
            kuantitas_menu = itemView.findViewById(R.id.tv_kuantitas_menu);
            getKM = kuantitas_menu.getText().toString();
            //getKM = getKuantitasMenu(kuantitas_menu);
        }
        public String getKuantitasMenu() {
            kM = kuantitas_menu.getText().toString();
            return kM;
        }
        public String returnIt(){
            getKM = getKuantitasMenu();
            return getKM;
        }
    }

    public int translateStrtoInt(String value){
        String value1 = value.replace(".", "");
        int value2 = Integer.parseInt(value1);
        return value2;
    }
}
